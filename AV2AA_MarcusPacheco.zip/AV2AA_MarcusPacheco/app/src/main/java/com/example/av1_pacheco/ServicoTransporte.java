package com.example.av1_pacheco;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class ServicoTransporte {
    private final UUID id;
    private final Date startDate;
    private Date endDate;
    private Carga carga;
    private String passageiro;

    public ServicoTransporte(String passageiro) {
        this.passageiro = passageiro;
        this.id = UUID.randomUUID();
        this.startDate = new Date();
    }

    public ServicoTransporte(Carga carga) { // polimorfismo
        this.id = UUID.randomUUID();
        this.startDate = new Date();
        this.carga = carga;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "ServicoTransporte{" +
                "id=" + id +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", carga=" + carga +
                ", passageiros=" + passageiro +
                '}';
    }

    public void logServico(){
        System.out.println(this.toString());
    }

    private class Carga {
        private String conteudo;
        private int peso = 0;
        private boolean fragil = false;

        public Carga(String conteudo, int peso, boolean fragil){
            this.conteudo = conteudo;
            this.peso = peso;
            this.fragil = fragil;
        }

        public String getConteudo() {
            return conteudo;
        }

        public int getPeso() {
            return peso;
        }

        public boolean isFragil() {
            return fragil;
        }
    }
}
