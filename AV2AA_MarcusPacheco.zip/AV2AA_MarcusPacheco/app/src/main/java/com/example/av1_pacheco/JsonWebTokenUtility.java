package com.example.av1_pacheco;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Date;

public class JsonWebTokenUtility {

    private static final String chave = "4317985356778213"; // 16 char

    public static String encrypt(String subject) {
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);

        return Jwts.builder()
                .setSubject(subject)
                .setIssuedAt(now)
                .signWith(SignatureAlgorithm.HS256, chave)
                .compact();
    }

    public static String decrypt(String jwt) {
        Claims claims = Jwts.parser()
                .setSigningKey(chave)
                .parseClaimsJws(jwt).getBody();
        return claims.getSubject();
    }
}
