package com.example.av1_pacheco;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;

import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class ThreadLocation extends Thread {

    private final Context context;
    private final LocationUpdateCallback callback;

    private LocationManager locationManager;
    private LocationListener locationListener;

    double totalDistance = 80000;
    double totalDuration = 0;

    int distanceTraveled = 0;
    int distanceTraveledinFlux = 0;
    double elapsedTime = 0;

    double somaTemposReconciliados = 0;

    double startTime = System.currentTimeMillis();

    private Handler mainHandler; // Adicionado

    int numeroDeNos = 80;
    int distanciaFluxo = (int) (totalDistance/numeroDeNos);
    double tempoHrsFluxo = ((totalDistance/numeroDeNos)/80000);
    private double velocidadeProximoFluxo = 80;

    private ArrayList<String> ServiceTags = new ArrayList<>();

    public ThreadLocation(Context context, LocationUpdateCallback callback) {
        this.context = context;
        this.callback = callback;
        this.mainHandler = new Handler(Looper.getMainLooper()); // Adicionado
    }

    @Override
    public void run() {
            locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

            locationListener = new LocationListener() {
                Location lastLocation = null;

                @Override
                public void onLocationChanged(Location location) {
                    if (lastLocation != null) {
                        distanceTraveled += lastLocation.distanceTo(location);
                        distanceTraveledinFlux += lastLocation.distanceTo(location);
                    }

                    double[] y = new double[numeroDeNos];
                    double[] v = new double[numeroDeNos];

                    for(int i = 0; i <numeroDeNos; i++){
                        y[i] = tempoHrsFluxo;
                        v[i] = 0.001;
                    }


                    if(distanceTraveled > 0){
                        if (distanceTraveledinFlux > distanciaFluxo) {
                            double tempoFluxo = System.currentTimeMillis() - startTime;
                            tempoFluxo = (tempoFluxo / 1000) / 3600;

                            y[0] = tempoHrsFluxo + (tempoHrsFluxo - tempoFluxo);
                            v[0] = v[0] + v[0]* Math.abs(y[1] - y[0]);
                            Reconciliation rec = new Reconciliation();
                            double[][] A = matrizDeIncidencia(numeroDeNos);
                            System.out.println("raw measurements: ");
                            rec.printMatrix(y);
                            System.out.println("standard deviation");
                            rec.printMatrix(v);
                            rec.reconcile(y, v, A);
                            System.out.println("Reconciled Flow: ");
                            double[] reconciledFlow = rec.getReconciledFlow();
                            rec.printMatrix(reconciledFlow);
                            distanceTraveledinFlux = 0;
                            velocidadeProximoFluxo = (distanciaFluxo/1000)/rec.getReconciledFlow()[0];
                            startTime = System.currentTimeMillis();
                            somaTemposReconciliados = getSomatorioReconciliaca(reconciledFlow);
                            numeroDeNos--;
                        }
                    }

                    lastLocation = location;
                    elapsedTime += 1;
                    callback.onLocationUpdate(totalDistance, totalDuration, distanceTraveled, elapsedTime, velocidadeProximoFluxo, somaTemposReconciliados);
                }
            };

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // Solicite as permissões necessárias aqui
                return;
            }

        if(!this.isInterrupted())
            {
                mainHandler.post(() -> locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locationListener)); // Modificado
            }
    }

    private double getSomatorioReconciliaca(double[] reconciledFlow) {
        double soma = 0;
        for(double value : reconciledFlow){
            soma =+ value;
        }
        return soma;
    }

    public void setTempoHrsFluxo(double tempoHrsFluxo) {
        this.tempoHrsFluxo = tempoHrsFluxo;
    }

    public static double[][] matrizDeIncidencia(int numNodes) {
        double[][] matriz = new double[numNodes - 1][numNodes];

        for (int i = 0; i < numNodes - 1; i++) {
            for (int j = 0; j < numNodes - 1; j++) {
                matriz[i][j] = -1;
            }
        }
        // Preencha a matriz para F1->F2->...FN
        for (int i = 0; i < numNodes - 1; i++) {
            matriz[i][i] = 1;
        }
        return matriz;
    }

    public void crossDocking(double tempoRestante, String tag) {
        if(somaTemposReconciliados < tempoRestante){
            setTempoHrsFluxo(tempoRestante/numeroDeNos);
        }
         if(!ServiceTags.contains(tag)){
             ServicoTransporte servicoTransporte = new ServicoTransporte("Marcus");
             servicoTransporte.logServico();
             ServiceTags.add(tag);
         }
    }

    public interface LocationUpdateCallback {
        void onLocationUpdate(double totalDistance, double totalDuration, double distanceTraveled, double elapsedTime, double velocidadeProximoFluxo, double tempoRestante);
    }
}
