    package com.example.av1_pacheco;

    import com.android.volley.Request;
    import com.android.volley.RequestQueue;
    import com.android.volley.Response;
    import com.android.volley.VolleyError;
    import com.android.volley.toolbox.StringRequest;
    import com.android.volley.toolbox.Volley;
    import android.content.Context;

    import java.nio.charset.StandardCharsets;

    public class NetworkManager {

        private static final String BASE_URL = "http://10.0.2.2:8080";
        private static NetworkManager instance = null;
        private RequestQueue requestQueue;
        private static Context ctx;

        private NetworkManager(Context context) {
            ctx = context;
            requestQueue = getRequestQueue();
        }

        public static synchronized NetworkManager getInstance(Context context) {
            if (instance == null) {
                instance = new NetworkManager(context);
            }
            return instance;
        }

        public RequestQueue getRequestQueue() {
            if (requestQueue == null) {
                requestQueue = Volley.newRequestQueue(ctx.getApplicationContext());
            }
            return requestQueue;
        }

        public <T> void addToRequestQueue(Request<T> req) {
            getRequestQueue().add(req);
        }
        public void post(String url, final String requestBody, Response.Listener<String> listener, Response.ErrorListener errorListener) {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, BASE_URL + url, listener, errorListener) {
                @Override
                public byte[] getBody() {
                    return requestBody.getBytes(StandardCharsets.UTF_8);
                }

                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }
            };

            addToRequestQueue(stringRequest);
        }

        public void get(String url, Response.Listener<String> listener, Response.ErrorListener errorListener) {
            StringRequest stringRequest = new StringRequest(Request.Method.GET, BASE_URL + url, listener, errorListener);
            addToRequestQueue(stringRequest);
        }
    }
