package com.example.av1_pacheco;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.android.volley.Response;
import com.android.volley.VolleyError;

import org.json.JSONObject;

import java.util.UUID;
import java.util.concurrent.Semaphore;


public class MainActivity extends AppCompatActivity implements ThreadLocation.LocationUpdateCallback {
    TextView distanciaTotal;
    TextView tempoTotal;
    TextView distanciaPercorrida;
    TextView tempoDecorrido;
    TextView velocidadeFluxo;

    Button startButton;
    Button stopButton;

    ThreadLocation locationThread;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private UUID myId = UUID.randomUUID();

    private final Semaphore sendSemaphore = new Semaphore(1);
    private final Semaphore receiveSemaphore = new Semaphore(1);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        distanciaTotal = findViewById(R.id.distancia_total);
        tempoTotal = findViewById(R.id.tempo_total);
        distanciaPercorrida = findViewById(R.id.distancia_percorrida);
        tempoDecorrido = findViewById(R.id.tempo_decorrido);
        velocidadeFluxo = findViewById(R.id.velocidade_fluxo);

        startButton = findViewById(R.id.start);
        stopButton = findViewById(R.id.stop);


        startButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationThread = new ThreadLocation(this, this);
                locationThread.start();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        LOCATION_PERMISSION_REQUEST_CODE);
            }
        });

        stopButton.setOnClickListener(v -> {
            if (locationThread != null) {
                locationThread.interrupt();
                locationThread = null;
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    locationThread = new ThreadLocation(this, this);
                    locationThread.start();
                } else {
                    Toast.makeText(this, "Permissão de localização necessária para o funcionamento do aplicativo.", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    @Override
    public void onLocationUpdate(double totalDistance, double totalDuration, double distanceTraveled, double elapsedTime, double velocidadeProximoFluxo, double tempoRestante) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                distanciaTotal.setText(String.valueOf(totalDistance/1000) + " km");
                tempoTotal.setText(String.valueOf(tempoRestante));
                distanciaPercorrida.setText(String.valueOf(distanceTraveled/1000) + "km");
                tempoDecorrido.setText(String.valueOf(elapsedTime) + " s");
                velocidadeFluxo.setText(String.valueOf(velocidadeProximoFluxo) + " km/h");

                sendEncryptedJson(myId.toString(), velocidadeProximoFluxo, tempoRestante);
                fetchFromServer();
            }
        });
    }

    public void sendEncryptedJson(String id, Double velocidade, double tempoRestante) {
        try {
            // Adquirir a permissão do semáforo para envio
            sendSemaphore.acquire();
            JSONManager jsonManager = new JSONManager();
            JsonWebTokenUtility cryptoManager = new JsonWebTokenUtility();

            // Cria JSON
            JSONObject json = jsonManager.createJson(id, velocidade);

            // Criptografa JSON
            String cipherText = cryptoManager.encrypt(json.toString());

            // Envia dados criptografados para o servidor
            com.example.av1_pacheco.NetworkManager.getInstance(this).post("/post", cipherText,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println("success: " + response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("failure: " + error.toString());
                    }
                }
            );
            // Liberar o semáforo após o envio
            sendSemaphore.release();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void fetchFromServer() {
        String url = "/http://10.0.2.2:8080";
        NetworkManager.getInstance(this).get(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    // Decodificar o JWT e obter o JSON
                    receiveSemaphore.acquire();
                    String decryptedData = JsonWebTokenUtility.decrypt(response);
                    JSONObject decryptedJsonData = new JSONObject(decryptedData);

                    if(!decryptedJsonData.has("id")){
                        return;
                    }
                    String id = decryptedJsonData.getString("id");

                    if(myId.toString() != id.toString()){
                        return;
                    }

                    if(!decryptedJsonData.has("velocidade")){
                        return;
                    }

                    double velocidade = decryptedJsonData.getDouble("velocidade");

                    if(!decryptedJsonData.has("tempoRestante")){
                        return;
                    }

                    double tempoRestante = decryptedJsonData.getDouble("tempoRestante");

                    locationThread.crossDocking(tempoRestante, (id.toString()+id.toString()));
                    receiveSemaphore.release();

                } catch (Exception e) {
                    System.out.println("Erro ao descriptografar os dados: " + e.getMessage());
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Erro ao recuperar os dados: " + error.toString());
            }
        });
    }

}
