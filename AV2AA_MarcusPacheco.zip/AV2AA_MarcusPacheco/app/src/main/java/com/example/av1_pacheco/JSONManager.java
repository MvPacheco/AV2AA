package com.example.av1_pacheco;

import org.json.JSONObject;

public class JSONManager {
    public JSONObject createJson(String id, Double velocidade) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id", id);
            jsonObject.put("speed", velocidade);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }
}
